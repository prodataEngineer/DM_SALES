SELECT
    customer_id,
    name,
    region_id
FROM {{ source('raw', 'customers') }}
