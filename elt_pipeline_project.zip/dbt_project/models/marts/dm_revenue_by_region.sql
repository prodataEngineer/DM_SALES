SELECT
    region_name,
    COUNT(order_id) AS total_orders,
    SUM(total_amount) AS total_revenue
FROM {{ ref('int_orders_enriched') }}
GROUP BY region_name
