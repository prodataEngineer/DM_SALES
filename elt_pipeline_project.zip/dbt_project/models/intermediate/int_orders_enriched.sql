SELECT
    o.order_id,
    o.customer_id,
    c.region_id,
    r.region_name,
    o.total_amount,
    o.order_date
FROM {{ ref('stg_orders') }} o
JOIN {{ ref('stg_customers') }} c ON o.customer_id = c.customer_id
JOIN {{ ref('stg_regions') }} r ON c.region_id = r.region_id
